package com.facturacion.contabilidad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContabilidadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContabilidadApplication.class, args);
	}
}
